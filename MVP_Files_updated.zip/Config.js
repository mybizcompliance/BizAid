// Backend selection
const BACKEND_MODE = "supabase";

// Supabase
const SUPABASE_URL = "";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJxaHdlbGJmam5oenNpaGpwaXViIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQ4MTI0MzIsImV4cCI6MjA4MDM4ODQzMn0.T5ui1VXuAGV7sLOXw3Phfy3LS8fbDujFgLBR-b6pI80";

// Google Sheets (optional)
const GOOGLE_SHEET_WEB_APP_URL = "";

// PayFast placeholders
const PAYFAST_MERCHANT_ID = "YOUR_MERCHANT_ID";
const PAYFAST_MERCHANT_KEY = "YOUR_MERCHANT_KEY";
const PAYFAST_SUBSCRIPTION_URL = "https://sandbox.payfast.co.za/eng/process";

// Email system
const FORMSUBMIT_EMAIL = "https://formsubmit.co/BizAidTeam@gmail.com";
