import qs from 'querystring'

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end()

  const {
    PAYFAST_MERCHANT_ID,
    PAYFAST_MERCHANT_KEY,
    PAYFAST_PASSPHRASE,
    PAYFAST_RETURN_URL,
    PAYFAST_CANCEL_URL,
    PAYFAST_NOTIFY_URL,
    APP_BASE_URL,
  } = process.env

  const { email, user_id, amount } = req.body

  // Build PayFast payment data (sandbox)
  const data = {
    merchant_id: PAYFAST_MERCHANT_ID,
    merchant_key: PAYFAST_MERCHANT_KEY,
    return_url: PAYFAST_RETURN_URL,
    cancel_url: PAYFAST_CANCEL_URL,
    notify_url: PAYFAST_NOTIFY_URL,
    amount: parseFloat(amount).toFixed(2),
    item_name: `Subscription for ${email}`,
    m_payment_id: `${user_id}-${Date.now()}`,
    email_address: email,
  }

  // Signature string: sort keys alphabetically, URL-encode values
  const signature = createPayfastSignature(data, PAYFAST_PASSPHRASE)
  const query = qs.stringify({ ...data, signature })

  // PayFast sandbox endpoint
  const payfastSandbox = 'https://sandbox.payfast.co.za/eng/process'

  // Redirect the user to PayFast sandbox to complete payment
  res.writeHead(302, { Location: `${payfastSandbox}?${query}` })
  res.end()
}

function createPayfastSignature(data, passphrase) {
  const keys = Object.keys(data).filter(k => data[k] !== undefined && data[k] !== null && data[k] !== '').sort()
  const parts = keys.map(k => `${k}=${encodeURIComponent(data[k])}`)
  const str = parts.join('&') + (passphrase ? `&passphrase=${encodeURIComponent(passphrase)}` : '')
  const crypto = require('crypto')
  return crypto.createHash('md5').update(str).digest('hex')
}
