import crypto from 'crypto'

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end()

  // PayFast posts form-encoded data
  const data = req.body

  const {
    PAYFAST_MERCHANT_ID,
    PAYFAST_MERCHANT_KEY,
    PAYFAST_PASSPHRASE,
    SUPABASE_SERVICE_ROLE_KEY,
    NEXT_PUBLIC_SUPABASE_URL,
  } = process.env

  // Verify mandatory fields
  if (!data || !data.signature || !data.m_payment_id) {
    return res.status(400).send('Missing fields')
  }

  // Recreate signature server-side
  const incomingSig = data.signature

  const params = Object.assign({}, data)
  delete params.signature

  const keys = Object.keys(params).filter(k => params[k] !== undefined && params[k] !== null && params[k] !== '').sort()
  const str = keys.map(k => `${k}=${params[k]}`).join('&') + (PAYFAST_PASSPHRASE ? `&passphrase=${PAYFAST_PASSPHRASE}` : '')
  const md5 = crypto.createHash('md5').update(str).digest('hex')

  if (md5 !== incomingSig) {
    console.warn('Invalid signature on PayFast webhook')
    return res.status(400).send('Invalid signature')
  }

  const paymentStatus = data.payment_status || ''

  if (paymentStatus === 'COMPLETE') {
    try {
      const { createClient } = require('@supabase/supabase-js')
      const supabaseAdmin = createClient(NEXT_PUBLIC_SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)

      const [user_id] = (data.m_payment_id || '').split('-')

      await supabaseAdmin.from('subscriptions').upsert({
        user_id,
        m_payment_id: data.m_payment_id,
        amount: data.amount_gross || data.amount || null,
        payment_status: paymentStatus,
        raw: data,
      }, { onConflict: ['m_payment_id'] })

      return res.status(200).send('OK')
    } catch (err) {
      console.error(err)
      return res.status(500).send('Server error')
    }
  }

  res.status(200).send('Ignored')
}

export const config = {
  api: {
    bodyParser: {
      sizeLimit: '1mb',
      type: 'application/x-www-form-urlencoded',
    }
  }
}
